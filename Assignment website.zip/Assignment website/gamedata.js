var roomArray = [
	{
		title:'room 1',
		text:'you are standing room 1',
		choices:[
			{
				text:'Go to room 2',
				index:1
			}
		]
	},
	{
		title:'room 2',
		text:'you are standing room 2',
		choices:[
			{
				text:'Go to room 1',
				index:0
			},
			{
				text:'Go to room 3',
				index:2
			}
		]
	},
	{
		title:'room 3',
		text:'you are standing room 3',
		choices:[
			{
				text:'Go to room 2',
				index:1
			}
		]
	}
]
